from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import User
from ..keyboards.main_menu import main_menu_kb, lang_kb, cancel_kb, CANCEL_TEXTS
from ..i18n import t

router = Router(name="auth")

LANG_LABELS = {
    "de": "🇩🇪 Deutsch",
    "ua": "🇺🇦 Українська",
    "ru": "🇷🇺 Русский",
    "en": "🇬🇧 English",
}


class RegistrationFSM(StatesGroup):
    waiting_name = State()
    waiting_lang = State()


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, session: AsyncSession, user: User | None):
    if user:
        await message.answer(
            t("welcome_back", user.lang, name=user.name),
            reply_markup=main_menu_kb(user.lang),
            parse_mode="HTML",
        )
        return

    await message.answer(
        t("welcome", "de"),   # до реєстрації — мова невідома, показуємо DE
        reply_markup=cancel_kb("de"),
        parse_mode="HTML",
    )
    await state.set_state(RegistrationFSM.waiting_name)


@router.message(RegistrationFSM.waiting_name, F.text)
async def reg_name(message: Message, state: FSMContext):
    if message.text in CANCEL_TEXTS:
        await state.clear()
        await message.answer(t("cancelled"), reply_markup=main_menu_kb())
        return
    name = message.text.strip()
    if len(name) < 2:
        await message.answer(t("name_too_short", "de"))
        return
    if len(name) > 100:
        await message.answer("Name zu lang (max. 100 Zeichen).")
        return
    await state.update_data(name=name)
    await message.answer(
        t("choose_lang", "de", name=name),
        reply_markup=lang_kb(),
        parse_mode="HTML",
    )
    await state.set_state(RegistrationFSM.waiting_lang)


@router.callback_query(RegistrationFSM.waiting_lang, F.data.startswith("lang:"))
async def reg_lang(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    lang = callback.data.split(":")[1]
    data = await state.get_data()
    name = data["name"]

    new_user = User(telegram_id=callback.from_user.id, name=name, lang=lang)
    session.add(new_user)
    await session.commit()
    await state.clear()

    await callback.message.edit_text(
        t("reg_done", lang, name=name, lang=LANG_LABELS.get(lang, lang)),
        parse_mode="HTML",
    )
    await callback.message.answer(t("main_menu", lang), reply_markup=main_menu_kb(lang))
    await callback.answer()


@router.message(F.text.in_({"⚙️ Налаштування", "⚙️ Настройки", "⚙️ Settings", "⚙️ Einstellungen"}))
async def settings_shortcut(message: Message):
    # Редирект до /settings хендлера
    from .settings import cmd_settings
    # просто викликаємо через команду
    await message.answer("/settings")
