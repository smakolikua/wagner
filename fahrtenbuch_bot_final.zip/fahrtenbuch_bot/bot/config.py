from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── Telegram ──────────────────────────────────────────────
    BOT_TOKEN: str

    # Webhook (залиште порожнім для polling)
    BOT_WEBHOOK_URL: str = ""
    WEBHOOK_PORT: int = 8443

    # ── База даних ────────────────────────────────────────────
    DATABASE_URL: str = "sqlite+aiosqlite:///./fahrtenbuch.db"

    # ── Геокодинг ─────────────────────────────────────────────
    GOOGLE_MAPS_API_KEY: str = ""

    # ── Трекінг (глобальний дефолт) ───────────────────────────
    GEOFENCE_RADIUS_METERS: int = 100

    # ── Часовий пояс ──────────────────────────────────────────
    TIMEZONE: str = "Europe/Berlin"

    # ── Адміністратор ─────────────────────────────────────────
    ADMIN_TELEGRAM_ID: Optional[int] = None

    # ── Sentry ────────────────────────────────────────────────
    SENTRY_DSN: str = ""

    # ── Логування ─────────────────────────────────────────────
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "logs/bot.log"


settings = Settings()
