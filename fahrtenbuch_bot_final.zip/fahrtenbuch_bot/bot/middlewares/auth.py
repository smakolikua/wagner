from typing import Callable, Awaitable, Any
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..models import User


class AuthMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        session: AsyncSession = data.get("session")
        user_obj = None

        tg_user = data.get("event_from_user")
        if tg_user and session:
            result = await session.execute(
                select(User).where(User.telegram_id == tg_user.id)
            )
            user_obj = result.scalar_one_or_none()

        data["user"] = user_obj

        # Якщо не зареєстрований і це не /start — редирект
        if user_obj is None and isinstance(event, Message):
            text = event.text or ""
            if not text.startswith("/start"):
                await event.answer(
                    "👋 Спочатку зареєструйтесь — надішліть /start"
                )
                return

        return await handler(event, data)
